difficulty_levels = {
    'beginner': 1,
    'intermediate': 2,
    'advanced': 3
}

courses = {
    'Mathematics': {'topic': 'mathematics', 'difficulty': 'Beginner', 'prerequisites': None},
    'Physics': {'topic': 'physics', 'difficulty': 'Intermediate', 'prerequisites': ['Mathematics']},
    'Chemistry': {'topic': 'chemistry', 'difficulty': 'Intermediate', 'prerequisites': ['Mathematics']},
    'Biology': {'topic': 'biology', 'difficulty': 'Beginner', 'prerequisites': None},
    'Advanced Mathematics': {'topic': 'mathematics', 'difficulty': 'Advanced', 'prerequisites': ['Mathematics']},
    'Programming Basics': {'topic': 'programming', 'difficulty': 'Beginner', 'prerequisites': None},
    'Advanced Physics': {'topic': 'physics', 'difficulty': 'Advanced', 'prerequisites': ['Physics']},
    'Computer Science': {'topic': 'computer science', 'difficulty': 'Intermediate', 'prerequisites': ['Programming Basics', 'Mathematics']},
    'Statistics': {'topic': 'mathematics', 'difficulty': 'Intermediate', 'prerequisites': ['Mathematics']},
    'Advanced Chemistry': {'topic': 'chemistry', 'difficulty': 'Advanced', 'prerequisites': ['Chemistry']},
    'Genetics': {'topic': 'biology', 'difficulty': 'Intermediate', 'prerequisites': ['Biology']},
    'Neuroscience': {'topic': 'biology', 'difficulty': 'Advanced', 'prerequisites': ['Biology']}
}

def has_prerequisites(course, completed_courses):
    prerequisites = courses[course].get('prerequisites')
    if prerequisites is None:
        return True
    return all(prerequisite in completed_courses for prerequisite in prerequisites)


def recommend_course(quiz_answers):
    recommended_courses = []
    completed_courses = []
    for course, attributes in courses.items():
        if (quiz_answers['topic'] == attributes['topic']) or (attributes['prerequisites'] and quiz_answers['topic'] in attributes['prerequisites']):
            if difficulty_levels[quiz_answers['difficulty'].lower()] >= difficulty_levels[attributes['difficulty'].lower()]:
                if has_prerequisites(course, completed_courses):
                    recommended_courses.append(course)
        completed_courses.append(course)
    return recommended_courses
