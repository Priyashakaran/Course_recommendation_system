from django.contrib import admin
from home.models import scienceformdata
from home.models import contactform
class scienceadmin(admin.ModelAdmin):
    list_display=('topic','difficulty','prerequisites')

class contactadmin(admin.ModelAdmin):
    list_display=('name','email','number','subject','message')
# Register your models here.
admin.site.register(scienceformdata,scienceadmin)

admin.site.register(contactform,contactadmin)