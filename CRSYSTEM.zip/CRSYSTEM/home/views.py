from multiprocessing import AuthenticationError
from django.shortcuts import render,HttpResponse,redirect
from .recommendation_code import recommend_course
from .arts_recom_code import artsrecommend_course
from .commerce_recom_code import commercerecommend_course
from home.models import scienceformdata
from home.models import contactform
from django.contrib.auth.models import User
from django.contrib.auth import authenticate
from django.contrib.auth import logout,login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
#password for test user Delgia is Dream**25 email dawson@gmail.com last name rose
# Create your views here.
def index(request):
    if request.user.is_anonymous:
        return redirect("/login") 
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def userprofile(request):
    return render(request, 'userprofile.html')


def contact(request):
    if request.method=='POST':
        Full_name=request.POST.get('fullname')
        email_add=request.POST.get('email')
        phonenumb=request.POST.get('phone')
        subject_con=request.POST.get('subject')
        message_con=request.POST.get('message')
        en=contactform(name=Full_name,email=email_add,number=phonenumb,subject=subject_con,message=message_con)
        en.save()
    return render(request, 'contact.html')

def scienceform(request):
    return render(request, 'scienceform.html')

def artsform(request):
    return render(request, 'artsform.html')

def comform(request):
    return render(request, 'comform.html')




@login_required
def userprofile(request):
    all_user_courses = scienceformdata.objects.all()
    all_recommended_courses = [course.recommended_courses for course in all_user_courses]
    return render(request, 'userprofile.html', {'recommended_courses': all_recommended_courses})


def signupUser(request):
    if request.method=='POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        username=request.POST['username']
        password = request.POST['password']
        data= User.objects.create_user(first_name=first_name,last_name=last_name,email=email,username=username,password=password)
        data.save()
        return redirect('login')
    return render(request,'signup.html')


def loginUser(request):
    if request.method=="POST":
        #CHECK IF USER HAS ENTERED CORRECT CREDENTIALS
        username= request.POST.get('username')
        password= request.POST.get('password')
        user =authenticate(username=username, password=password)
        if user is not None:
            login(request,user)
            #a backend authenticated the credentials
            return redirect("/")
        else:  
            print("Incorrect password")
            
    return render(request, 'login.html')


def logoutUser(request):
    logout(request)
    return redirect('/login')

def recommend_courses(request):
    if request.method == 'POST':
        topic_choice = request.POST.get('topic', '').strip().lower()  # Ensure consistent capitalization
        difficulty_choice = request.POST.get('difficulty', '').strip().lower()  # Ensure consistent capitalization
        prerequisites = request.POST.get('prerequisites', '').strip().lower()
        # Storing user's answers in a dictionary
        quiz_answers = {
            'topic': topic_choice,
            'difficulty': difficulty_choice,
            'prerequisites': prerequisites.split(',') if prerequisites else []
        }

        # Process quiz answers, e.g., pass them to recommendation logic
        recommended_courses = recommend_course(quiz_answers)
        en=scienceformdata(topic=topic_choice,difficulty=difficulty_choice,prerequisites=prerequisites,recommended_courses=recommended_courses)
        en.save()
        return render(request, 'sciencerecom.html', {'recommended_courses': recommended_courses})

    return render(request, 'scienceform.html')


def artsrecommend_courses(request):
    if request.method == 'POST':
        topic_choice = request.POST.get('topic', '').strip().lower()  # Ensure consistent capitalization
        difficulty_choice = request.POST.get('difficulty', '').strip().lower()  # Ensure consistent capitalization
        prerequisites = request.POST.get('prerequisites', '').strip().lower()
        # Storing user's answers in a dictionary
        quiz_answers = {
            'topic': topic_choice,
            'difficulty': difficulty_choice,
            'prerequisites': prerequisites.split(',') if prerequisites else []
        }

        # Process quiz answers, e.g., pass them to recommendation logic
        artsrecommended_courses = artsrecommend_course(quiz_answers)
        return render(request, 'artsrecom.html', {'artsrecommended_courses': artsrecommended_courses})

    return render(request, 'artsform.html')

def commercerecommend_courses(request):
    if request.method == 'POST':
        topic_choice = request.POST.get('topic', '').strip().lower()  # Ensure consistent capitalization
        difficulty_choice = request.POST.get('difficulty', '').strip().lower()  # Ensure consistent capitalization
        prerequisites = request.POST.get('prerequisites', '').strip().lower()
        # Storing user's answers in a dictionary
        quiz_answers = {
            'topic': topic_choice,
            'difficulty': difficulty_choice,
            'prerequisites': prerequisites.split(',') if prerequisites else []
        }

        # Process quiz answers, e.g., pass them to recommendation logic
        commercerecommended_courses = commercerecommend_course(quiz_answers)
        return render(request, 'comrecom.html', {'commercerecommended_courses': commercerecommended_courses})

    return render(request, 'comform.html')



