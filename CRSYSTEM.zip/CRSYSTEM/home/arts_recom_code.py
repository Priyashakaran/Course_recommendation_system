difficulty_levels = {
    'beginner': 1,
    'intermediate': 2,
    'advanced': 3
}

artscourses = {
    'History': {'topic': 'history', 'difficulty': 'Beginner', 'prerequisites': None},
    'Literature': {'topic': 'literature', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Philosophy': {'topic': 'philosophy', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Fine Arts': {'topic': 'fine arts', 'difficulty': 'Beginner', 'prerequisites': None},
    'Advanced Literature': {'topic': 'literature', 'difficulty': 'Advanced', 'prerequisites': ['Literature']},
    'Art History': {'topic': 'history', 'difficulty': 'Intermediate', 'prerequisites': ['History']},
}


def has_prerequisites(artscourse, artscompleted_courses):
    prerequisites = artscourses[artscourse].get('prerequisites')
    if prerequisites is None:
        return True
    return all(prerequisite in artscompleted_courses for prerequisite in prerequisites)


def artsrecommend_course(quiz_answers):
    artsrecommended_courses = []
    artscompleted_courses = []
    topic_choice = quiz_answers['topic']
    difficulty_choice = quiz_answers['difficulty']
    prerequisites = quiz_answers['prerequisites']

    for artscourse, attributes in artscourses.items():
        if (quiz_answers['topic'] == attributes['topic']) or (attributes['prerequisites'] and quiz_answers['topic'] in attributes['prerequisites']):
            if difficulty_levels[difficulty_choice.lower()] >= difficulty_levels[attributes['difficulty'].lower()]:
                if has_prerequisites(artscourse, artscompleted_courses):
                    artsrecommended_courses.append(artscourse)
        artscompleted_courses.append(artscourse)
    return artsrecommended_courses
