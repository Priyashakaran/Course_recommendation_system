difficulty_levels = {
    'beginner': 1,
    'intermediate': 2,
    'advanced': 3
}

commercecourses = {
    'Economics': {'topic': 'economics', 'difficulty': 'Beginner', 'prerequisites': None},
    'Business Management': {'topic': 'business management', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Accounting': {'topic': 'accounting', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Marketing': {'topic': 'marketing', 'difficulty': 'Beginner', 'prerequisites': None},
    'Finance Fundamentals': {'topic': 'finance', 'difficulty': 'Intermediate', 'prerequisites': None},
    'International Business': {'topic': 'business management', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Human Resource Management': {'topic': 'human resources', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Operations Management': {'topic': 'operations management', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Entrepreneurship': {'topic': 'entrepreneurship', 'difficulty': 'Beginner', 'prerequisites': None},
    'Supply Chain Management': {'topic': 'supply chain management', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Strategic Management': {'topic': 'strategic management', 'difficulty': 'Advanced', 'prerequisites': ['Business Management']},
    'Digital Marketing': {'topic': 'marketing', 'difficulty': 'Intermediate', 'prerequisites': ['Marketing']},
    'Financial Accounting': {'topic': 'accounting', 'difficulty': 'Advanced', 'prerequisites': ['Accounting']},
    'Corporate Finance': {'topic': 'finance', 'difficulty': 'Advanced', 'prerequisites': ['Finance Fundamentals']},
    'Organizational Behavior': {'topic': 'organizational behavior', 'difficulty': 'Intermediate', 'prerequisites': None},
    'Business Ethics': {'topic': 'business ethics', 'difficulty': 'Intermediate', 'prerequisites': None},
}



def has_prerequisites(commercecourse, commercecompleted_courses):
    prerequisites = commercecourses[commercecourse].get('prerequisites')
    if prerequisites is None:
        return True
    return all(prerequisite in commercecompleted_courses for prerequisite in prerequisites)


def commercerecommend_course(quiz_answers):
    commercerecommended_courses = []
    commercecompleted_courses = []
    topic_choice = quiz_answers['topic']
    difficulty_choice = quiz_answers['difficulty']
    prerequisites = quiz_answers['prerequisites']

    for commercecourse, attributes in commercecourses.items():
        if (quiz_answers['topic'] == attributes['topic']) or (attributes['prerequisites'] and quiz_answers['topic'] in attributes['prerequisites']):
            if difficulty_levels[difficulty_choice.lower()] >= difficulty_levels[attributes['difficulty'].lower()]:
                if has_prerequisites(commercecourse, commercecompleted_courses):
                    commercerecommended_courses.append(commercecourse)
        commercecompleted_courses.append(commercecourse)
    return commercerecommended_courses
