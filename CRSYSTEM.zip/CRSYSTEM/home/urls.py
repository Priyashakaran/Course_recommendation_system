from django.contrib import admin
from django.urls import path
from home import views
urlpatterns = [
    path("",views.index,name='home'),
    path("about",views.about,name='about' ),
    path("contact",views.contact,name='contact' ),
    path('recommend-courses/', views.recommend_courses, name='recommend_courses'),
    path('arts-recommend-courses/', views.artsrecommend_courses, name='artsrecommend_courses'),
     path('commerce-recommend-courses/', views.commercerecommend_courses, name='commercerecommend_courses'),
    path("scienceform",views.scienceform,name='scienceform' ),
    path("artsform",views.artsform,name='artsform' ),
    path("comform",views.comform,name='comform' ),
    path("login",views.loginUser,name="login"),
    path("logout",views.logoutUser,name="logout"),
    path("signup",views.signupUser,name="signup"),
     path("userprofile",views.userprofile,name="userprofile"),

]